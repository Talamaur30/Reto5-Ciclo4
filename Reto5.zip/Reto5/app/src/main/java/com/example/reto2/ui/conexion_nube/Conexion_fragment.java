package com.example.reto2.ui.conexion_nube;

import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.reto2.R;
import com.example.reto2.adaptadores.ProductoAdapter;
import com.example.reto2.casos_uso.CasoUsoProducto;
import com.example.reto2.datos.DBHelper;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Conexion_fragment extends Fragment {
    View v;
    Button botonGET;
    TextView mostrarJSON;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        v=inflater.inflate(R.layout.fragment_productos_nube, container,false);
        try{

            botonGET = (Button) v.findViewById(R.id.botonGET);
            mostrarJSON = (TextView) v.findViewById(R.id.mostrarJSON);

            botonGET.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    lladoGET();
                }
            });

        }catch (Exception e){
            Toast.makeText(getContext(), e.toString(), Toast.LENGTH_LONG).show();
        }

        return v;
    }

    private void lladoGET() {
        String url = "https://g0009ba250cddf2-dbciclomovil.adb.sa-saopaulo-1.oraclecloudapps.com/ords/admin/tabla/tabla";


        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                try {
                    JSONArray jsonArray = response.getJSONArray("items");
                    for(int i = 0; i < jsonArray.length(); i++){
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        mostrarJSON.setText(jsonObject.toString());
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        requestQueue.add(jsonObjectRequest);

    }

}

